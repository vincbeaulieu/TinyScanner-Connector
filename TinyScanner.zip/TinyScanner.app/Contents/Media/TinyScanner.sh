cd $(dirname $0)
wget --recursive --no-parent --no-clobber http://192.168.2.28:10000/